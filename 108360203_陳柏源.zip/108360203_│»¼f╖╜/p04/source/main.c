#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int n[10],i;
	for (i = 0; i < 10; i++)
	{
		n[i] = 0;
	}
	printf("%20s%20s\n", "Element", "Value");
	for (i = 0; i < 10; i++)
	{
		printf("%20d%20d\n", i, n[i]);
	}
	system("pause");
	return 0;
	
}