#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int n[10] = { 32,27,64,18,95,14,90,70,60,37 };
	int i;
	printf("%20s%20s\n", "Element", "Value");
	for (i = 0; i < 10; i++)
	{
		printf("%20d%20d\n", i, n[i]);
	}
	system("pause");
	return 0;
}