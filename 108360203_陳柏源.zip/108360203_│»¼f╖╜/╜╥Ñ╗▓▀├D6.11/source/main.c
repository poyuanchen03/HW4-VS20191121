#include<stdio.h>
#include<stdlib.h>
#define NUMBER 8
int main(void)
{
	int a[NUMBER] = { 5,13,14,6,40,32,80,28 };
	int i;
	int temp;
	int pass;
	printf("��l���ƾڸ��:");

	for (i = 0; i < NUMBER; i++)
	{
		printf("%d\t", a[i]);

	}
	for (pass = 1; pass < NUMBER - 1; pass++)
	{
		for (i = 0; i < NUMBER - 1; i++)
		{
			if (a[i] > a[i + 1])
			{
				temp = a[i];
				a[i] = a[i + 1];
				a[i+1] = temp;
			}
		}
	}
	printf("\n");
	printf("�g�L�ƧǸ��:  ");
	for (i = 0; i < NUMBER; i++)
	{
		printf("%d\t", a[i]);
	}
	printf("\n");
	system("pause");
	return 0;
}